'''
Name Julia Perrotta
email jperrot3@binghamton.edu
Lab Section and CA Name B57 Owen Ifferte
Assignment # 2
'''

## Do not write anything past column 78
## Go to next line instead (no wrapping!)
## USE MEANINGFUL NAMES!
## variables will use lower_snake_case
## constants will use UPPER_SNAKE_CASE

'''
ANALYSIS

RESTATE the problem clearly and without ambiguity
This program will output the total price of a purchase including sales tax
given the price of a single item.

OUTPUT to monitor:
  total_price (float) - total purchase price including tax
  . . .

INPUT from keyboard:
  number_of_items (int)
  price_of_item (float) - price of item not including tax
  . . .

GIVENS (i.e., program constants):

  STATE_SALES_TAX (float) => .05
  COUNTY_SALES_TAX (float) => .025
  
PROCESSING:
  Quick summary, usually describes Input/Process/Output (IPO) pattern
The user will input the number of items and the price of one item as strings.
These strings will be converted to float and int to be used in an equation.
The output is the total price of all items multiplied by the sales tax.

'''

#IMPORTS

# CONSTANTS (NO LITERALS ALLOWED!  Except 1, -1, and 0)
STATE_SALES_TAX = .05
COUNTY_SALES_TAX = .025

## BRIEF description of overall program
# This program outputs the total price of a purchase with sales tax
def main():
  ## START by giving the overall flow of your program in comments,
  ##   then interleave your code
 
  # Explain purpose of program to user
 print("This program will print out the total purchase price " +
      "given the price of a single item.")
  # enter input values, negative numbers will return garbage
  # entering strings will crash the program
number_of_items_str = input("Enter the number of items: ")
price_of_item_str = input("Enter the price of one item: $")

  # You may need to convert the input
number_of_items = int(number_of_items_str) 
price_of_item = float(price_of_item_str)

  # Usually you will have to process the input in some way to get the outputs
total_sales_tax = STATE_SALES_TAX + COUNTY_SALES_TAX
total_price = (number_of_items * price_of_item) * (1 + total_sales_tax)
  # output
print("The total price of all the items with tax is: " + \
        "$%.2f" % (total_price))
  

if __name__ == '__main__':
  main()
